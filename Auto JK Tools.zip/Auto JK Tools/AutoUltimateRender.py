bl_info = {
    "name": "template",
    "author": "Your Name Here",
    "version": (1, 0),
    "blender": (2, 80, 0),
    "location": "View3D > Add > Mesh > New Object",
    "description": "Adds a new Mesh Object",
    "warning": "",
    "doc_url": "",
    "category": "Add Mesh",
}


import bpy
from bpy.types import Operator, Panel, PropertyGroup, Menu
from bpy.props import BoolProperty, FloatProperty, IntProperty, PointerProperty,StringProperty
from bpy_extras.object_utils import AddObjectHelper, object_data_add
from mathutils import Vector

import bpy
import os
import importlib
         

def selectTitle(title):
    coll = bpy.data.collections['Titles']
    for i in range(len(coll.all_objects)):
        obj = coll.all_objects[i]
        if obj.name != title:
            print(obj.hide_render)
            obj.hide_render = True
            obj.hide_viewport = True
            obj.hide_select = True
        else:
            print(obj.name)
            obj.hide_render = False
            obj.hide_viewport = False
            obj.hide_select = False
            
def selectName(name):
    coll = bpy.data.collections['Names']
    for i in range(len(coll.all_objects)):
        obj = coll.all_objects[i]
        if obj.name != name:
            print(obj.hide_render)
            obj.hide_render = True
            obj.hide_viewport = True
            obj.hide_select = True
        else:
            print(obj.name)
            obj.hide_render = False
            obj.hide_viewport = False
            obj.hide_select = False
            
def changeBackground(color):
    #changeMaterial
    for obj in bpy.data.objects:
        if obj.name != 'BackgroundColor':
            obj.select_set(False)
        else:
            obj.select = True
            bpy.context.view_layer.objects.active = obj
    # BackgroundColor is selected, so must have a material
    
    mat=bpy.context.active_object.active_material # mat never null
    tree=mat.node_tree.nodes
    backgroundNode = tree.get("Background Image")
    
    if color == 'Red':
        bpy.ops.image.open(filepath = '//Background Colors//Background_Red.png')
        bgImage = bpy.data.images['Background_Red.png']
    elif color == 'Orange':
        bpy.ops.image.open(filepath = '//Background Colors//Background_Orange.png')
        bgImage = bpy.data.images['Background_Orange.png']
    elif color == 'Blue':
        bpy.ops.image.open(filepath = '//Background Colors//Background_Blue.png')
        bgImage = bpy.data.images['Background_Blue.png']
    elif color == 'Purple':
        bpy.ops.image.open(filepath = '//Background Colors//Background_Purple.png')
        bgImage = bpy.data.images['Background_Purple.png']
    
    print(bgImage)    
    backgroundNode.image = bgImage
    
    #changeShadow        
    shadow_red = [0.068381, 0.009078, 0.034835, 1.0]
    shadow_orange = [0.068380, 0.016252, 0.010204, 1.0]
    shadow_blue = [0.007923, 0.01253, 0.06838, 1.0]
    shadow_purple = [0.0248607, 0.005285, 0.068379, 1.0]

    for a in bpy.context.screen.areas:
        if a.type == 'NODE_EDITOR' and a.ui_type == 'CompositorNodeTree':
            area = a
    print(area)
    bpy.context.scene.use_nodes = True
    composeTree = bpy.context.scene.node_tree
    for node in composeTree.nodes:
        if node.name == 'Shadow Color':
            if color == 'Red':
                node.outputs[0].default_value = shadow_red
            elif color == 'Orange':
                node.outputs[0].default_value = shadow_orange
            elif color == 'Blue':
                node.outputs[0].default_value = shadow_blue
            elif color == 'Purple':
                node.outputs[0].default_value = shadow_purple
    
def showExplorer():
    path = "C:/tmp"
    path = os.path.realpath(path)
    os.startfile(path)
    

    


    
class BackgroundColor(Menu):
    bl_label = "节点名称"
    description = '版头需要显示的节点名称'
    bl_idname = "rabichora.background_menu"

    def draw(self, context):
        layout = self.layout

        layout.operator("auto.back_change_red")
        layout.operator("auto.back_change_orange")
        layout.operator("auto.back_change_blue")
        layout.operator("auto.back_change_putple")
        

class REAL_PT_AutoPanel(Panel):
    bl_space_type = "VIEW_3D"
    bl_context = ""
    bl_region_type = "UI"
    bl_label = "AutoRender"
    bl_category = u"AutoRender"

    def draw(self, context):
        scn = context.scene
        layout = self.layout


        col = layout.column(align=True)


        bl_label = "AutoMaterial tools"

        row = layout.row(align=True)
        row.scale_y = 1.5
        
        layout.menu(BackgroundColor.bl_idname)
    
    
#=================================
# CLASSES
#=================================
from . import (BackgroundColorClasses)

classes = {
    REAL_PT_AutoPanel
}

#cls.union(color_classes)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
